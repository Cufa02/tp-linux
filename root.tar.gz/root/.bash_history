history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname
hostnamectl set-hostname TPServer
hostname
cat /etc/debian_version
ls_release -a
lsb_release -a
apt update
apt upgrade
apt full-upgrade
reboot
cat /etc/debian_version
nano /etc/apt/sources.list
cat /etc/apt/sources.list
vim /etc/apt/sources.list
apt update
vim /etc/apt/sources.list
apt update
apt upgrade
apt full-upgrade
reboot
cat /etc/debian_version
cat /etc/apt/sources.list
apt-cache plicy
apt-cache policy
apt update
ip a
ping 8.8.8.8
cat /etc/resolv.conf
ping deb.debian.org
cat /etc/apt/sources.list 
vim /etc/apt/sources.list 
cat /etc/apt/sources.list
nano /etc/apt/sources.list
vim /etc/apt/sources.list
pin deb.debian.org
ping deb.debian.org
apt update
vim /etc/apt/sources.list
apt update
apt- full-upgrade
apt full-upgrade
reboot
cat /etc/debian_version
systemctl status ssh
apt update
apt install openssh-server -y
systemctl status ssh
systemctl enable ssh
systemctl start ssh
ss -tlnp | grep ssh
ssh-keygen -t ed25519
cat ~/.ssh/id_ed25519.pub >> ~/.ssh/authorized_keys
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
vim /etc/ssh/sshd_config
systemctl restart ssh
ssh localhost
apt update
apt install apache2 
systemctl is-active apache2
apt install php libapache2-mod-php
php -v
ls -l /root
cp /root/index.php /var/www/html/
ls -la /root
tar Material_Adicional_TPVMCA.tar.gz
tar -tzf Material_Adicional_TPVMCA.tar.gz
tar -xzf Material_Adicional_TPVMCA.tar.gz
ls -la
ls -la /root
ls -l /root/index.php /root/logo.png
apachectl -S
find / -name "index.php 2>/dev/null

find / -name "index.php" 2>/dev/null
find / -name "index.php" 2>/dev/null
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls -l /var/www/html/
apt update
apt install mariadb-server -y
systemctl enable mariadb
systemctl start mariadb
mysql
find /root -name "db.sql"
head db.sql
cd /root/Material_Adicional_TPVMCA/
head db.sql 
mysql < /root/Material_Adicional_TPVMCA/db.sql 
mysql
cd /
ip a
vim /etc/network/interfaces
ip a | grep enp0s3 -A2
iproute
ip route
vim /etc/network/interfaces
ip a
ip route
ip a
ip route
ip a
ip route
ip a
ip route
ip link set enp0s3 up
ip a
dhclient enp0s3
ip a
ip route
